# language: Python 3.11+, file: core/utils.py
# *random identity generation + proxy loader*
import random
import string
import json
from pathlib import Path
from typing import Optional


_FIRST = [
    "Liam","Noah","Oliver","James","Elijah","Mateo","Theodore","Henry","Lucas","William",
    "Emma","Olivia","Ava","Sophia","Isabella","Mia","Luna","Charlotte","Amelia","Harper",
    "Ethan","Mason","Logan","Aiden","Jackson","Sebastian","Jack","Owen","Samuel","Ryan",
    "Lily","Zoe","Hannah","Aria","Grace","Chloe","Penelope","Layla","Nora","Riley",
    "Kai","Jordan","Quinn","Alex","Skylar","Morgan","Taylor","Blake","Cameron","Avery",
]

_LAST = [
    "Smith","Johnson","Williams","Brown","Jones","Garcia","Miller","Davis","Wilson","Taylor",
    "Moore","Anderson","Thomas","Jackson","White","Harris","Martin","Thompson","Young","Allen",
    "King","Wright","Scott","Green","Baker","Adams","Hill","Ramirez","Campbell","Mitchell",
    "Carter","Roberts","Gonzalez","Lewis","Robinson","Walker","Perez","Hall","Young","Hernandez",
]

_ADJECTIVES = ["dark","lost","cold","neon","void","wild","deep","fast","slow","bright"]
_NOUNS      = ["wave","beat","echo","flux","drift","vibe","pulse","node","core","arc"]


def random_display_name() -> str:
    style = random.randint(0, 3)
    if style == 0:
        return random.choice(_FIRST) + random.choice(_LAST) + str(random.randint(10, 999))
    elif style == 1:
        return random.choice(_ADJECTIVES) + random.choice(_NOUNS) + str(random.randint(10, 99))
    elif style == 2:
        adj = random.choice(_ADJECTIVES)
        noun = random.choice(_NOUNS)
        return f"{adj}_{noun}_{random.randint(100, 9999)}"
    else:
        base = "".join(random.choices(string.ascii_lowercase, k=random.randint(5, 9)))
        return base + str(random.randint(10, 9999))


def random_password(length: int = 16) -> str:
    chars = string.ascii_letters + string.digits + "!@#$%^&*"
    while True:
        pw = "".join(random.choices(chars, k=length))
        if (any(c.isupper() for c in pw)
                and any(c.islower() for c in pw)
                and any(c.isdigit() for c in pw)
                and any(c in "!@#$%^&*" for c in pw)):
            return pw


def random_dob() -> dict:
    year  = random.randint(1990, 2001)
    month = random.randint(1, 12)
    import calendar
    max_day = calendar.monthrange(year, month)[1]
    day = random.randint(1, max_day)
    return {"year": year, "month": month, "day": day}


def random_gender() -> str:
    return random.choice(["male", "female", "nonbinary"])


def load_proxies(path: Path) -> list:
    if not path.exists():
        return []
    lines = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line and not line.startswith("#"):
            lines.append(line)
    return lines


def proxy_to_nodriver(proxy_str: str) -> Optional[str]:
    """Normalize proxy string to nodriver-compatible format."""
    s = proxy_str.strip()
    if not s:
        return None
    if s.startswith(("http://", "https://", "socks5://", "socks4://")):
        return s
    # bare ip:port or ip:port:user:pass
    parts = s.split(":")
    if len(parts) == 2:
        return f"http://{parts[0]}:{parts[1]}"
    if len(parts) == 4:
        return f"http://{parts[2]}:{parts[3]}@{parts[0]}:{parts[1]}"
    return f"http://{s}"


def load_config(path: Path) -> dict:
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def save_account(path: Path, email: str, password: str, display: str, verified: bool, uuid: str = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    status = "verified" if verified else "unverified"
    parts  = [email, password, display, status]
    if uuid:
        parts.append(uuid)
    with open(path, "a", encoding="utf-8") as f:
        f.write(":".join(parts) + "\n")
