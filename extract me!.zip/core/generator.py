# language: Python 3.11+, file: core/generator.py, target: Spotify signup — nodriver browser automation
# *nodriver = undetected chromium, no selenium, direct CDP — handles hCaptcha via nopecha ext*
import asyncio
import time
import random
from pathlib import Path
from typing import Optional

import nodriver as uc

from .tempmail import TempMailAPI
from .utils    import (
    random_display_name, random_password, random_dob,
    random_gender, proxy_to_nodriver, save_account,
)

SIGNUP_URL = "https://www.spotify.com/signup/"

_GENDER_MAP = {
    "male":     "male",
    "female":   "female",
    "nonbinary": "nonbinary",
}

_MONTH_MAP = {
    1: "January", 2: "February", 3: "March",    4: "April",
    5: "May",     6: "June",     7: "July",      8: "August",
    9: "September", 10: "October", 11: "November", 12: "December",
}


async def _type_slow(elem, text: str, delay: float = 0.05) -> None:
    """Mimic human typing pace."""
    for ch in text:
        await elem.send_keys(ch)
        await asyncio.sleep(random.uniform(delay * 0.5, delay * 1.5))


async def _wait_and_click(tab, selector: str, timeout: float = 15.0) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            el = await tab.select(selector)
            if el:
                await el.click()
                return True
        except Exception:
            pass
        await asyncio.sleep(0.4)
    return False


async def _wait_for_element(tab, selector: str, timeout: float = 15.0):
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            el = await tab.select(selector)
            if el:
                return el
        except Exception:
            pass
        await asyncio.sleep(0.4)
    return None


class SpotifyGenerator:
    def __init__(
        self,
        mail_api:     TempMailAPI,
        output_path:  Path,
        solver_ext:   Optional[Path] = None,
        proxy:        Optional[str]  = None,
        headless:     bool           = False,
        nopecha_key:  str            = "",
    ):
        self.mail_api    = mail_api
        self.output_path = output_path
        self.solver_ext  = solver_ext   # path to nopecha / solver ext folder
        self.proxy       = proxy_to_nodriver(proxy) if proxy else None
        self.headless    = headless
        self.nopecha_key = nopecha_key

    async def _build_browser(self):
        import tempfile, random as _r

        _BROWSERS = [
            # Edge first — most common on Win11
            r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
            r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
            # Brave
            r"C:\Program Files\BraveSoftware\Brave-Browser\Application\brave.exe",
            r"C:\Program Files (x86)\BraveSoftware\Brave-Browser\Application\brave.exe",
            # Chrome
            r"C:\Program Files\Google\Chrome\Application\chrome.exe",
            r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        ]
        exe = next((p for p in _BROWSERS if Path(p).exists()), None)

        _w, _h = _r.choice([
            (1280, 720), (1366, 768), (1440, 900), (1920, 1080),
        ])

        args = [
            "--disable-blink-features=AutomationControlled",
            "--no-first-run",
            "--no-default-browser-check",
            "--disable-infobars",
            "--disable-notifications",
            "--disable-save-password-bubble",
            "--disable-translate",
            "--disable-sync",
            "--disable-background-networking",
            "--lang=en-US",
            f"--window-size={_w},{_h}",
        ]

        if self.proxy:
            args.append(f"--proxy-server={self.proxy}")

        # extension loading — mirrors token gen exactly
        ext_args = []
        if self.solver_ext and self.solver_ext.exists():
            ext_str = str(self.solver_ext)
            ext_args = [
                f"--load-extension={ext_str}",
                f"--disable-extensions-except={ext_str}",
                "--disable-features=DisableDisableExtensionsExceptCommandLineSwitch,DisableLoadExtensionCommandLineSwitch",
            ]

        tmp_profile = tempfile.mkdtemp(prefix="sp_browser_")
        args.append(f"--user-data-dir={tmp_profile}")

        kwargs = {
            "headless":    self.headless,
            "browser_args": [*ext_args, *args],
        }
        if exe:
            kwargs["browser_executable_path"] = exe

        self._tmp_profile = tmp_profile
        return await uc.start(**kwargs)

    # ── step 1 — email ──────────────────────────────────────────────────────

    async def _fill_email(self, tab, email: str) -> bool:
        el = await _wait_for_element(tab, 'input[id="username"]', timeout=20)
        if not el:
            el = await _wait_for_element(tab, 'input[type="email"]', timeout=5)
        if not el:
            return False
        await el.clear_input()
        await _type_slow(el, email)
        await asyncio.sleep(random.uniform(0.3, 0.7))

        btn = await _wait_for_element(tab, 'button[data-testid="submit"]', timeout=5)
        if not btn:
            btn = await _wait_for_element(tab, 'button[type="submit"]', timeout=5)
        if btn:
            await btn.click()
        return True

    # ── step 2 — password ───────────────────────────────────────────────────

    async def _fill_password(self, tab, password: str) -> bool:
        el = await _wait_for_element(tab, 'input[id="new-password"]', timeout=15)
        if not el:
            el = await _wait_for_element(tab, 'input[type="password"]', timeout=5)
        if not el:
            return False
        await el.clear_input()
        await _type_slow(el, password)
        await asyncio.sleep(random.uniform(0.3, 0.6))

        btn = await _wait_for_element(tab, 'button[data-testid="submit"]', timeout=5)
        if not btn:
            btn = await _wait_for_element(tab, 'button[type="submit"]', timeout=5)
        if btn:
            await btn.click()
        return True

    # ── step 3 — profile (name + DOB + gender) ──────────────────────────────

    async def _fill_profile(self, tab, name: str, dob: dict, gender: str) -> bool:
        # display name
        name_el = await _wait_for_element(tab, 'input[id="displayName"]', timeout=15)
        if not name_el:
            name_el = await _wait_for_element(tab, 'input[data-testid="displayName"]', timeout=5)
        if name_el:
            await name_el.clear_input()
            await _type_slow(name_el, name)
            await asyncio.sleep(random.uniform(0.2, 0.5))

        # DOB — month: native <select> set via JS, fire change event so React picks it up
        month_val = str(dob["month"])
        await tab.evaluate(
            f"""
            (function() {{
                var sel = document.querySelector('select#month') ||
                          document.querySelector('select[id="month"]') ||
                          document.querySelector('select[name="month"]');
                if (!sel) return;
                sel.value = '{month_val}';
                sel.dispatchEvent(new Event('change', {{bubbles: true}}));
                sel.dispatchEvent(new Event('input',  {{bubbles: true}}));
            }})()
            """
        )
        await asyncio.sleep(0.25)

        # DOB — day input
        day_el = await _wait_for_element(tab, 'input[id="day"]', timeout=5)
        if not day_el:
            day_el = await _wait_for_element(tab, 'input[name="day"]', timeout=5)
        if day_el:
            await day_el.clear_input()
            await _type_slow(day_el, str(dob["day"]))
            await asyncio.sleep(0.2)

        # DOB — year input
        year_el = await _wait_for_element(tab, 'input[id="year"]', timeout=5)
        if not year_el:
            year_el = await _wait_for_element(tab, 'input[name="year"]', timeout=5)
        if year_el:
            await year_el.clear_input()
            await _type_slow(year_el, str(dob["year"]))
            await asyncio.sleep(0.2)

        # gender — try radio first, fall back to JS set on native select
        gender_val = _GENDER_MAP.get(gender, "male")
        gender_radio = await _wait_for_element(
            tab,
            f'input[type="radio"][value="{gender_val}"]',
            timeout=5,
        )
        if gender_radio:
            await gender_radio.click()
            await asyncio.sleep(0.2)
        else:
            # Spotify sometimes uses a <select> for gender
            await tab.evaluate(
                f"""
                (function() {{
                    var sel = document.querySelector('select#gender') ||
                              document.querySelector('select[name="gender"]') ||
                              document.querySelector('select[id="gender"]');
                    if (!sel) return;
                    sel.value = '{gender_val}';
                    sel.dispatchEvent(new Event('change', {{bubbles: true}}));
                    sel.dispatchEvent(new Event('input',  {{bubbles: true}}));
                }})()
                """
            )
            await asyncio.sleep(0.2)

        # submit profile step
        btn = await _wait_for_element(tab, 'button[data-testid="submit"]', timeout=5)
        if not btn:
            btn = await _wait_for_element(tab, 'button[type="submit"]', timeout=5)
        if btn:
            await btn.click()
        return True

    # ── step 4 — consent: just hit the button ───────────────────────────────

    async def _fill_consent(self, tab) -> bool:
        await asyncio.sleep(1)
        btn = await _wait_for_element(tab, 'button[data-testid="submit"]', timeout=10)
        if not btn:
            btn = await _wait_for_element(tab, 'button[type="submit"]', timeout=5)
        if btn:
            await btn.click()
        return True

    # ── redirect detection ────────────────────────────────────────────────────

    async def _wait_for_redirect(self, tab, timeout: float = 120.0) -> dict:
        """
        Wait until Spotify redirects away from /signup.
        Returns dict with 'success' bool and optional 'uuid' pulled from ubi param.
        Download page redirect = confirmed account creation.
        """
        import base64
        from urllib.parse import urlparse, parse_qs, unquote

        deadline = time.time() + timeout
        while time.time() < deadline:
            try:
                url = await tab.evaluate("window.location.href") or ""
            except Exception:
                try:
                    url = tab.url or ""
                except Exception:
                    url = ""

            _success = (
                "/download/" in url
                or "open.spotify.com" in url
                or "/account/overview" in url
                or "/home" in url
            )

            if not _success:
                await asyncio.sleep(1.5)
                continue

            if "spotify.com" in url:
                uuid = None
                # download page carries ubi param with account UUID
                if "/download/" in url:
                    try:
                        qs  = parse_qs(urlparse(url).query)
                        ubi = qs.get("ubi", [None])[0]
                        if ubi:
                            raw = base64.b64decode(unquote(ubi) + "==")
                            # UUID is the first length-delimited string field — scan for hyphen pattern
                            import re as _re
                            m = _re.search(
                                rb'([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})',
                                raw
                            )
                            if m:
                                uuid = m.group(1).decode()
                    except Exception:
                        pass

                return {"success": True, "uuid": uuid, "redirect": url}

            await asyncio.sleep(1.5)

        return {"success": False, "uuid": None, "redirect": None}

    # ── main run ──────────────────────────────────────────────────────────────

    async def run_one(self, log_fn=None) -> dict:
        def log(msg):
            if log_fn:
                log_fn(msg)

        result = {"success": False, "email": None, "password": None, "display": None, "verified": False}

        # 1. create inbox
        log("creating temp inbox...")
        email = self.mail_api.create_inbox()
        if not email:
            log("✗ failed to create inbox")
            return result
        result["email"] = email
        log(f"inbox: {email}")

        password = random_password()
        display  = random_display_name()
        dob      = random_dob()
        gender   = random_gender()
        result["password"] = password
        result["display"]  = display

        browser = None
        try:
            browser = await self._build_browser()

            # initialize nopecha solver before hitting signup
            if self.nopecha_key:
                try:
                    setup_tab = await browser.get(f"https://nopecha.com/setup#{self.nopecha_key}")
                    await asyncio.sleep(2.5)
                except Exception:
                    pass

            tab = await browser.get(SIGNUP_URL)
            await asyncio.sleep(random.uniform(1.5, 2.5))

            # 2. email step
            log("filling email...")
            if not await self._fill_email(tab, email):
                log("✗ email field not found")
                return result
            await asyncio.sleep(random.uniform(1.0, 2.0))

            # 3. password step
            log("filling password...")
            await self._fill_password(tab, password)
            await asyncio.sleep(random.uniform(1.0, 2.0))

            # 4. profile step
            log("filling profile...")
            await self._fill_profile(tab, display, dob, gender)
            await asyncio.sleep(random.uniform(1.0, 2.0))

            # 5. consent
            log("accepting terms...")
            await self._fill_consent(tab)
            await asyncio.sleep(random.uniform(1.5, 3.0))

            # 6. wait for redirect away from signup (captcha solve + account creation)
            log("waiting for account creation...")
            redir = await self._wait_for_redirect(tab, timeout=120)
            if not redir["success"]:
                log("✗ redirect timeout — account may not have been created")
                return result

            uuid = redir.get("uuid")
            if uuid:
                log(f"uuid: {uuid}")

            # 7. save
            save_account(self.output_path, email, password, display, verified=False, uuid=uuid)
            result["success"]  = True
            result["verified"] = False
            result["uuid"]     = uuid
            log(f"✓ account created — {email}")

        except Exception as e:
            log(f"✗ error: {e}")
        finally:
            try:
                if browser:
                    browser.stop()
            except Exception:
                pass
            try:
                import shutil as _sh
                _sh.rmtree(getattr(self, "_tmp_profile", ""), ignore_errors=True)
            except Exception:
                pass

        return result
