# language: Python 3.11+, file: core/premium.py, target: Spotify premium trial applicator
# *nodriver: login → premium page → free trial button → payments.spotify.com → card fill*
import asyncio
import random
import re
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import nodriver as uc

_BROWSERS = [
    r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\BraveSoftware\Brave-Browser\Application\brave.exe",
    r"C:\Program Files (x86)\BraveSoftware\Brave-Browser\Application\brave.exe",
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
]

LOGIN_URL   = "https://accounts.spotify.com/en/login"
PREMIUM_URL = "https://open.spotify.com/premium"


@dataclass
class VCC:
    number: str
    month:  str
    year:   str
    cvv:    str


def load_accounts(path: Path) -> list[dict]:
    """Parse output/accounts.txt → list of {email, password} dicts."""
    if not path.exists():
        return []
    accounts = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split(":")
        if len(parts) >= 2:
            accounts.append({"email": parts[0], "password": parts[1]})
    return accounts


def load_vccs(path: Path) -> list[VCC]:
    """
    Parse vcc.txt.
    Supported formats (| or : separator):
      number|mm|yy|cvv
      number|mm/yy|cvv
      number:mm:yy:cvv
      number:mm/yy:cvv
    """
    if not path.exists():
        return []
    vccs = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        sep = "|" if "|" in line else ":"
        parts = [p.strip() for p in line.split(sep)]
        if len(parts) == 4:
            number, mm, yy, cvv = parts
        elif len(parts) == 3:
            # number|mm/yy|cvv
            number = parts[0]
            exp    = parts[1]
            cvv    = parts[2]
            if "/" in exp:
                mm, yy = exp.split("/", 1)
            else:
                mm, yy = exp[:2], exp[2:]
        else:
            continue
        # normalise year to 2-digit
        yy = yy.strip()[-2:]
        vccs.append(VCC(number=number.replace(" ", ""), month=mm.strip(), year=yy, cvv=cvv.strip()))
    return vccs


async def _wait_for(tab, selector: str, timeout: float = 20.0):
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            el = await tab.select(selector)
            if el:
                return el
        except Exception:
            pass
        await asyncio.sleep(0.5)
    return None


async def _type_slow(el, text: str, lo: float = 0.05, hi: float = 0.14) -> None:
    await el.click()
    await asyncio.sleep(random.uniform(0.1, 0.25))
    for ch in text:
        await el.send_keys(ch)
        await asyncio.sleep(random.uniform(lo, hi))


async def _wait_url_contains(tab, fragment: str, timeout: float = 45.0) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            url = await tab.evaluate("window.location.href") or ""
        except Exception:
            url = ""
        if fragment in url:
            return True
        await asyncio.sleep(1.0)
    return False


class PremiumApplicator:
    def __init__(
        self,
        output_path: Path,
        vcc_path:    Path,
        headless:    bool = False,
    ):
        self.output_path = output_path
        self.vcc_path    = vcc_path
        self.headless    = headless

    async def _build_browser(self):
        import tempfile
        exe = next((p for p in _BROWSERS if Path(p).exists()), None)
        w, h = random.choice([(1280, 720), (1366, 768), (1920, 1080)])
        tmp  = tempfile.mkdtemp(prefix="sp_prem_")
        self._tmp = tmp
        args = [
            "--disable-blink-features=AutomationControlled",
            "--no-first-run",
            "--no-default-browser-check",
            "--disable-infobars",
            "--disable-notifications",
            "--disable-sync",
            "--lang=en-GB",
            f"--window-size={w},{h}",
            f"--user-data-dir={tmp}",
        ]
        kwargs = {"headless": self.headless, "browser_args": args}
        if exe:
            kwargs["browser_executable_path"] = exe
        return await uc.start(**kwargs)

    async def _login(self, tab, email: str, password: str) -> bool:
        """Fill Spotify login form at accounts.spotify.com."""
        user_el = await _wait_for(tab, 'input[id="login-username"]', timeout=20)
        if not user_el:
            user_el = await _wait_for(tab, 'input[data-testid="login-username"]', timeout=5)
        if not user_el:
            return False
        await _type_slow(user_el, email)
        await asyncio.sleep(random.uniform(0.3, 0.6))

        pass_el = await _wait_for(tab, 'input[id="login-password"]', timeout=10)
        if not pass_el:
            pass_el = await _wait_for(tab, 'input[data-testid="login-password"]', timeout=5)
        if not pass_el:
            return False
        await _type_slow(pass_el, password)
        await asyncio.sleep(random.uniform(0.3, 0.6))

        btn = await _wait_for(tab, 'button[id="login-button"]', timeout=8)
        if not btn:
            btn = await _wait_for(tab, 'button[data-testid="login-button"]', timeout=5)
        if not btn:
            btn = await _wait_for(tab, 'button[type="submit"]', timeout=5)
        if btn:
            await btn.click()
        return True

    async def _click_trial_button(self, tab) -> bool:
        """
        Find and click the free-trial CTA on open.spotify.com/premium.
        Button text variants: "Try 2 months for £0" / "Get Premium" / "Try free for 2 months"
        """
        selectors = [
            'a[data-testid="cta-button"]',
            'a[data-testid="premium-cta"]',
            'button[data-testid="premium-cta"]',
        ]
        for sel in selectors:
            el = await _wait_for(tab, sel, timeout=5)
            if el:
                await el.click()
                return True

        # fallback: scan all anchors/buttons for trial text
        found = await tab.evaluate("""
        (function() {
            var patterns = ['Try', 'free', '£0', 'Get Premium', 'Start'];
            var els = [...document.querySelectorAll('a, button')];
            for (var el of els) {
                var txt = (el.innerText || '').trim();
                if (patterns.some(function(p){ return txt.indexOf(p) !== -1; }) && txt.length < 80) {
                    el.click();
                    return txt;
                }
            }
            return null;
        })()
        """)
        return bool(found)

    async def _fill_card(self, tab, vcc: VCC) -> bool:
        """
        Fill card details on payments.spotify.com/checkout/.
        Fields live inside an iframe — target it directly via tab.evaluate
        because nodriver select() won't cross frame boundaries by default.
        """
        # first click "Credit or debit card" option
        card_option_selectors = [
            '[data-testid="payment-method-card"]',
            '[aria-label*="Credit"]',
            '[aria-label*="card"]',
            'button[class*="card"]',
        ]
        for sel in card_option_selectors:
            el = await _wait_for(tab, sel, timeout=8)
            if el:
                await el.click()
                await asyncio.sleep(1.0)
                break
        else:
            # look for text
            await tab.evaluate("""
            (function() {
                var els = [...document.querySelectorAll('button, [role="button"], label, div[tabindex]')];
                for (var el of els) {
                    var t = (el.innerText || el.textContent || '').toLowerCase();
                    if (t.includes('credit') || t.includes('debit') || t.includes('card')) {
                        el.click();
                        return;
                    }
                }
            })()
            """)
            await asyncio.sleep(1.2)

        # wait for card number field (likely inside an iframe — Stripe/Adyen embedded)
        # try direct selector first
        card_num_el = await _wait_for(tab, 'input[name="cardNumber"]', timeout=10)
        if not card_num_el:
            card_num_el = await _wait_for(tab, 'input[autocomplete="cc-number"]', timeout=5)
        if not card_num_el:
            card_num_el = await _wait_for(tab, 'input[data-testid="card-number"]', timeout=5)

        if card_num_el:
            await _type_slow(card_num_el, vcc.number)
            await asyncio.sleep(random.uniform(0.4, 0.7))
        else:
            # iframe path — inject via JS into the first payment frame
            filled = await tab.evaluate(f"""
            (function() {{
                var frames = [...document.querySelectorAll('iframe')];
                for (var f of frames) {{
                    try {{
                        var doc = f.contentDocument || f.contentWindow.document;
                        var inp = doc.querySelector('input[name="cardNumber"]') ||
                                  doc.querySelector('input[autocomplete="cc-number"]') ||
                                  doc.querySelector('input[data-fieldtype="encryptedCardNumber"]');
                        if (inp) {{
                            inp.focus();
                            inp.value = '{vcc.number}';
                            inp.dispatchEvent(new Event('input', {{bubbles:true}}));
                            inp.dispatchEvent(new Event('change', {{bubbles:true}}));
                            return 'ok';
                        }}
                    }} catch(e) {{}}
                }}
                return null;
            }})()
            """)
            if not filled:
                return False
            await asyncio.sleep(0.4)

        # expiry month
        exp_month_el = await _wait_for(tab, 'input[name="expiryMonth"]', timeout=5)
        if not exp_month_el:
            exp_month_el = await _wait_for(tab, 'input[autocomplete="cc-exp-month"]', timeout=3)
        if exp_month_el:
            await _type_slow(exp_month_el, vcc.month)
            await asyncio.sleep(random.uniform(0.2, 0.4))

        # expiry year
        exp_year_el = await _wait_for(tab, 'input[name="expiryYear"]', timeout=5)
        if not exp_year_el:
            exp_year_el = await _wait_for(tab, 'input[autocomplete="cc-exp-year"]', timeout=3)
        if exp_year_el:
            await _type_slow(exp_year_el, vcc.year)
            await asyncio.sleep(random.uniform(0.2, 0.4))

        # combined expiry field fallback (MM/YY)
        if not exp_month_el and not exp_year_el:
            exp_el = await _wait_for(tab, 'input[autocomplete="cc-exp"]', timeout=5)
            if not exp_el:
                exp_el = await _wait_for(tab, 'input[name="expiry"]', timeout=3)
            if exp_el:
                await _type_slow(exp_el, f"{vcc.month}/{vcc.year}")
                await asyncio.sleep(random.uniform(0.2, 0.4))

        # CVV
        cvv_el = await _wait_for(tab, 'input[name="securityCode"]', timeout=5)
        if not cvv_el:
            cvv_el = await _wait_for(tab, 'input[autocomplete="cc-csc"]', timeout=3)
        if not cvv_el:
            cvv_el = await _wait_for(tab, 'input[name="cvc"]', timeout=3)
        if cvv_el:
            await _type_slow(cvv_el, vcc.cvv)
            await asyncio.sleep(random.uniform(0.3, 0.5))

        return True

    async def apply_one_async(self, account: dict, vcc: VCC, log) -> dict:
        result = {
            "success": False,
            "email":   account["email"],
            "status":  "failed",
        }
        browser = None
        try:
            browser = await self._build_browser()

            # ── login ──────────────────────────────────────────────────────────
            log("opening login page...")
            tab = await browser.get(LOGIN_URL)
            await asyncio.sleep(random.uniform(1.5, 2.5))

            log("logging in...")
            if not await self._login(tab, account["email"], account["password"]):
                log("✗ login fields not found")
                return result

            # wait for redirect away from login page
            log("waiting for login redirect...")
            logged_in = await _wait_url_contains(tab, "open.spotify.com", timeout=30)
            if not logged_in:
                # also accept /home, /collection, account overview
                logged_in = await _wait_url_contains(tab, "spotify.com", timeout=15)
            if not logged_in:
                log("✗ login timeout")
                return result

            await asyncio.sleep(random.uniform(1.0, 2.0))

            # ── premium page ───────────────────────────────────────────────────
            log("navigating to premium page...")
            tab = await browser.get(PREMIUM_URL)
            await asyncio.sleep(random.uniform(2.0, 3.5))

            log("clicking trial button...")
            if not await self._click_trial_button(tab):
                log("✗ trial button not found")
                return result

            # ── checkout ───────────────────────────────────────────────────────
            log("waiting for checkout page...")
            on_checkout = await _wait_url_contains(tab, "payments.spotify.com/checkout", timeout=30)
            if not on_checkout:
                log("✗ checkout redirect timeout")
                return result

            await asyncio.sleep(random.uniform(1.5, 2.5))

            log("filling card details...")
            if not await self._fill_card(tab, vcc):
                log("✗ card fields not found")
                return result

            log("✓ card filled — ready to submit")
            result["success"] = True
            result["status"]  = "card_filled"

            # pause so user can see the filled form / manually confirm if needed
            await asyncio.sleep(3.0)

        except Exception as exc:
            log(f"✗ error: {exc}")
        finally:
            try:
                if browser:
                    browser.stop()
            except Exception:
                pass
            try:
                import shutil as _sh
                _sh.rmtree(getattr(self, "_tmp", ""), ignore_errors=True)
            except Exception:
                pass

        return result

    def apply_one(self, account: dict, vcc: VCC, log_fn=None) -> dict:
        def log(msg):
            if log_fn:
                log_fn(msg)
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            return loop.run_until_complete(self.apply_one_async(account, vcc, log))
        finally:
            loop.close()
