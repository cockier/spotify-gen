# language: Python 3.11+, file: core/tempmail.py, target: regret.world API
# *POST /inboxes → address | GET /inboxes/{addr}/messages → messages[] | GET /inboxes/{addr}/messages/{uid} → text/html*
import re
import time
import random
import requests
from typing import Optional


RW_BASE    = "https://regret.world/api/v1"
RW_DOMAINS = ["regret.world", "hurtful.lol"]


class TempMailAPI:
    def __init__(self, api_key: str, timeout: int = 30):
        self.key     = api_key
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {api_key}",
            "Content-Type":  "application/json",
        })

    def _h(self) -> dict:
        return {
            "Authorization": f"Bearer {self.key}",
            "Content-Type":  "application/json",
        }

    # ── inbox creation ───────────────────────────────────────────────────────

    def create_inbox(self) -> Optional[str]:
        """POST /inboxes → returns email address string or None."""
        domain = random.choice(RW_DOMAINS)
        try:
            r = self.session.post(
                f"{RW_BASE}/inboxes",
                json={"domain": domain},
                timeout=self.timeout,
            )
            if r.status_code not in (200, 201):
                return None
            return r.json().get("address")
        except Exception:
            return None

    # ── inbox polling ────────────────────────────────────────────────────────

    def get_messages(self, email: str) -> list:
        """GET /inboxes/{addr}/messages → list of message dicts."""
        try:
            r = self.session.get(
                f"{RW_BASE}/inboxes/{email}/messages",
                timeout=self.timeout,
            )
            if r.status_code == 200:
                return r.json().get("messages", [])
        except Exception:
            pass
        return []

    def get_message_body(self, email: str, uid: str) -> dict:
        """GET /inboxes/{addr}/messages/{uid} → full message body."""
        try:
            r = self.session.get(
                f"{RW_BASE}/inboxes/{email}/messages/{uid}",
                timeout=self.timeout,
            )
            if r.status_code == 200:
                return r.json()
        except Exception:
            pass
        return {}

    def delete_inbox(self, email: str) -> None:
        """DELETE /inboxes/{addr}"""
        try:
            self.session.delete(f"{RW_BASE}/inboxes/{email}", timeout=10)
        except Exception:
            pass

    # ── wait for verify email ────────────────────────────────────────────────

    def wait_for_message(
        self,
        email:         str,
        sender_hint:   str = "spotify",
        subject_hint:  str = "verify",
        max_wait:      int = 120,
        poll_interval: int = 3,
    ) -> Optional[dict]:
        """
        Poll inbox until a Spotify verify email lands.
        Returns the full message body dict or None on timeout.
        """
        deadline = time.time() + max_wait
        seen_uids: set = set()

        while time.time() < deadline:
            for msg in self.get_messages(email):
                uid  = msg.get("uid")
                frm  = str(msg.get("from", "")).lower()
                subj = str(msg.get("subject", "")).lower()

                if uid in seen_uids:
                    continue
                seen_uids.add(uid)

                if sender_hint.lower() not in frm and subject_hint.lower() not in subj:
                    continue

                # fetch full body
                body = self.get_message_body(email, uid)
                if body:
                    return body

            time.sleep(poll_interval)

        return None

    # ── link extraction ──────────────────────────────────────────────────────

    @staticmethod
    def extract_verify_link(message: dict) -> Optional[str]:
        """Pull Spotify verification URL out of message body."""
        import html as _html
        text = message.get("text") or ""
        html = message.get("html") or ""
        if isinstance(text, bytes):
            text = text.decode("utf-8", errors="replace")

        plain = text or _html.unescape(html)

        patterns = [
            r'https://accounts\.spotify\.com/[^\s\'"<>]+confirm[^\s\'"<>]+',
            r'https://accounts\.spotify\.com/[^\s\'"<>]+verify[^\s\'"<>]+',
            r'https://www\.spotify\.com/[^\s\'"<>]+activate[^\s\'"<>]+',
        ]
        for pat in patterns:
            m = re.search(pat, plain, re.IGNORECASE)
            if m:
                return m.group(0).rstrip(".")

        # fallback: any accounts.spotify.com link
        m = re.search(r'https://accounts\.spotify\.com/[^\s\'"<>]+', plain)
        return m.group(0).rstrip(".") if m else None
